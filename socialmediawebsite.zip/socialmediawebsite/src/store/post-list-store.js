import React, { createContext, useReducer } from "react";

export const PostList = createContext({
    postList: [],
    addPost: () => { },
    deletePost: () => { },
});

const postListReducer = (currPostList, action) => {
    let newPostList = [...currPostList]; 
    if (action.type === "DELETE_POST") {
        newPostList = currPostList.filter((post) => post.id !== action.payload.postId);
    } else if (action.type === "ADD_POST"){
        newPostList = [action.payload, ...currPostList]
    }
    return newPostList;
}

const PostListProvider = ({ children }) => {
    const [postList, dispatchPostList] = useReducer(
        postListReducer, DEFAULT_POST_LIST
    );

    // const addPost = (userId, postTitle, postBody, reactions, tags, image) => {
        const addPost = (userId, postTitle, postBody, reactions, tags) => {
        dispatchPostList({
            type: "ADD_POST",
            payload: {
                id: Date.now(),
                title: postTitle,
                body: postBody,
                reactions: reactions,
                userId: userId,
                tags: tags,
                //image: image,
            }
        })
    };

    const deletePost = (postId) => {
        dispatchPostList({
            type: "DELETE_POST",
            payload: {
                postId,
            },
        });
    };

    return (
        <PostList.Provider value={{ postList, addPost, deletePost }}>
            {children}
        </PostList.Provider>
    );
};

const DEFAULT_POST_LIST = [{
    id: '1',
    title: 'Going to mumbai',
    body: 'hi friend im going to mumbai for my vacation',
    reactions: 2,
    userId: 'user-9',
    tags: ["vacation", "Mumbai", "Enjoying"],
    //image: "socialmediaproject/images/socialmediaapp.jpeg",
},
{
    id: '2',
    title: 'Going to nashik',
    body: 'hi friend im going to nashik for my vacation',
    reactions: 4,
    userId: 'user-10',
    tags: ["vacation", "Nashik", "Enjoying"],
    //image: "socialmediaproject/public/socialmediaapp2.jpeg",
}
];

export default PostListProvider;