import { useRef } from "react";
import { useContext } from "react";
import { PostList } from "../store/post-list-store";

const CreatePost = () => {
  const { addPost } = useContext(PostList);
  const userIdElement = useRef();
  const postTitleElement = useRef();
  const postBodyElement = useRef();
  const reactionsElement = useRef();
  const tagsElement = useRef();
//  const imageElement = useRef();

  const handleSubmit = (event) => {
    event.preventDefault();
    const userId = userIdElement.current.value;
    const postTitle = postTitleElement.current.value;
    const postBody = postBodyElement.current.value;
    const reactions = reactionsElement.current.value;
    const tags = tagsElement.current.value.split(' ');
   // const image = imageElement.current.value;

    userIdElement.current.value = '';
    postTitleElement.current.value = '';
    postBodyElement.current.value = '';
    reactionsElement.current.value = '';
    tagsElement.current.value = '';
    // imageElement.current.value = '';

    // addPost(userId, postTitle, postBody, reactions, tags, image)
    addPost(userId, postTitle, postBody, reactions, tags)
  }


  return (
    <form className="create-post" onSubmit={handleSubmit}>

      <div className="mb-3">
        <label htmlFor="userId" className="form-label">
          Enter your User ID here
        </label>
        <input type="text"
          ref={userIdElement}
          className="form-control"
          id="userId"
          placeholder="Your User ID"
        />
      </div>

      <div className="mb-3">
        <label htmlFor="title" className="form-label">Post Title</label>
        <input type="text"
          className="form-control"
          ref={postTitleElement}
          id="title"
          placeholder="How are you feeling today..."
        />
      </div>

      <div className="mb-3">
        <label htmlFor="body" className="form-label">Post Content</label>
        <textarea type="text"
          rows="4"
          className="form-control"
          ref={postBodyElement}
          id="title"
          placeholder="Tell us more about it."
        />
      </div>

      <div className="mb-3">
        <label htmlFor="reactions"
          className="form-label">Number of reactions</label>
        <input type="text"
          className="form-control"
          ref={reactionsElement}
          id="reactions"
          placeholder="How many people reacted to this post"
        />
      </div>

      <div className="mb-3">
        <label htmlFor="hashtags"
          className="form-label">Enter Your HashTags here</label>
        <input type="text"
          className="form-control"
          ref={tagsElement}
          id="hashtags"
          placeholder="Enter HashTags"
        />
        <div id="body" className="form-text">We'll share your post to public.</div>
      </div>
      
      {/* <div className="mb-3">
        <label htmlFor="body" className="form-label">Image Path</label>
        <input type="text"
          rows="2"
          className="form-control"
          ref={imageElement}
          id="image"
          placeholder="Give the Image Path here"
        />
      </div> */}

      <button type="submit" className="btn btn-primary">Submit</button>
    </form>
  );
}

export default CreatePost;